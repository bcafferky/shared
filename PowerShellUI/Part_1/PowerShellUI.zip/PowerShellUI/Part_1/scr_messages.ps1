﻿<#  
     Writing different types of messages.
#>

Clear-Host

Write-Information "It's nice outside today."  

Write-Warning "It may rain later."

Write-Error "Hurricane alert in the area."
