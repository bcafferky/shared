﻿<#
  D:
  CD \DocumentsD\Presentations\PowerShellUI\Part_3
#>

Set-Location D:\DocumentsD\Presentations\PowerShellUI\Part_3


. .\frmSQLQuery.ps1
. .\CodeSQLQuery.ps1

