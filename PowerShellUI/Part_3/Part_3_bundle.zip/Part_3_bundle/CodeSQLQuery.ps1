﻿
function Invoke-UdfSQLStatement
{ 
 [CmdletBinding()]
        param (
              [string]$Server,
              [string]$Database,
              [string]$SQL,
              [switch]$IsSelect
          )

  Write-Verbose "Open Connecton"

  $conn = new-object System.Data.SqlClient.SqlConnection("Data Source=$Server;Integrated Security=SSPI;Initial Catalog=$Database");

  $conn.Open()

  $command = new-object system.data.sqlclient.Sqlcommand($SQL,$conn)

  if ($IsSelect) 
  { 
     
     $adapter = New-Object System.Data.sqlclient.SqlDataAdapter $command
     $dataset = New-Object System.Data.DataSet
     $adapter.Fill($dataset) | Out-Null
     $conn.Close()
     RETURN $dataset.tables[0] 
  }
  Else
  {
     $command.ExecuteNonQuery()
     $conn.Close()
  }
}

function btnExecute_Click() 
{
   $server = $txtServer.Text
   $database = $txtDatabase.Text
   $rowlimit = $cmbRowLimit.Text
   
   IF ($rowlimit -eq "ALL") 
    {
      $filter = "SELECT "
    }
    ELSE
    {
      $filter = "SELECT TOP $rowlimit " 
    } 
   

   $sql =  ($txtQuery.Text).REPLACE("SELECT ", $filter) 

   Invoke-UdfSQLStatement -Server $server -Database $database `
                          -SQL $sql -IsSelect | 
                          Out-GridView -Title 'Query Results'
    
}

function btnClose_Click () 
{
  $frmMain.Close()
}

# Show the form
$frmMain.ShowDialog()

<# Example call 

$result = Invoke-UdfSQLStatement -Server '(local)' -Database 'Development' -SQL 'select top 10 * from dbo.Person' -IsSelect 

#>
