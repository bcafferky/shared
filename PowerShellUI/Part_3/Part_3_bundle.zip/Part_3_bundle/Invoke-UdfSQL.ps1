﻿function Invoke-UdfSQLStatement
{ 
 [CmdletBinding()]
        param (
              [string]$Server,
              [string]$Database,
              [string]$SQL,
              [switch]$IsSelect
          )

  Write-Verbose "Open Connecton"

  $conn = new-object System.Data.SqlClient.SqlConnection("Data Source=$Server;Integrated Security=SSPI;Initial Catalog=$Database");

  $conn.Open()

  $command = new-object system.data.sqlclient.Sqlcommand($SQL,$conn)

  if ($IsSelect) 
  { 
     
     $adapter = New-Object System.Data.sqlclient.SqlDataAdapter $command
     $dataset = New-Object System.Data.DataSet
     $adapter.Fill($dataset) | Out-Null
     $conn.Close()
     RETURN $dataset.tables[0] 
  }
  Else
  {
     $command.ExecuteNonQuery()
     $conn.Close()
  }
}

<# Example call 

$result = Invoke-UdfSQLStatement -Server '(local)' -Database 'Development' -SQL 'select top 10 * from dbo.Person' -IsSelect 

$result

$Name = "Soap"
$Description = "Bar of Soap"
$Brand = "Irish Spring"

$insql = "INSERT INTO dbo.ShoppingList (Name, Description, Brand) VALUES ('$Name', '$Description', '$Brand');"

Invoke-UdfSQLStatement -Server '(local)' -Database 'Development' -SQL $insql  

$insql = "SELECT * FROM dbo.ShoppingList;"
	
$ShoppingListResult = Invoke-UdfSQLStatement -Server '(local)' -Database 'Development' -SQL $insql -IsSelect
	

#>
