﻿<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    poshguidemoA
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = '312,271'
$Form.text                       = "Demo"
$Form.TopMost                    = $false

$btnGetProcess                   = New-Object system.Windows.Forms.Button
$btnGetProcess.BackColor         = "#4a90e2"
$btnGetProcess.text              = "Get Process"
$btnGetProcess.width             = 99
$btnGetProcess.height            = 30
$btnGetProcess.location          = New-Object System.Drawing.Point(98,159)
$btnGetProcess.Font              = 'Microsoft Sans Serif,10'
$btnGetProcess.ForeColor         = "#ffffff"

$lblName                         = New-Object system.Windows.Forms.Label
$lblName.text                    = "Name:"
$lblName.AutoSize                = $true
$lblName.width                   = 25
$lblName.height                  = 10
$lblName.location                = New-Object System.Drawing.Point(59,95)
$lblName.Font                    = 'Microsoft Sans Serif,10'

$txtName                         = New-Object system.Windows.Forms.TextBox
$txtName.multiline               = $false
$txtName.BackColor               = "#f8e71c"
$txtName.width                   = 100
$txtName.height                  = 20
$txtName.location                = New-Object System.Drawing.Point(108,90)
$txtName.Font                    = 'Microsoft Sans Serif,10'

$Form.controls.AddRange(@($btnGetProcess,$lblName,$txtName))

$btnGetProcess.Add_Click({ btnGetProcess_Click })

function btnGetProcess_Click { 

    Get-Process $txtName.Text | Out-Gridview 

}


#Write your logic code here



[void]$Form.ShowDialog()

