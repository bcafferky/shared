﻿<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    queryform
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$frmMain                         = New-Object system.Windows.Forms.Form
$frmMain.ClientSize              = '906,520'
$frmMain.text                    = "Form"
$frmMain.BackColor               = "#4a90e2"
$frmMain.TopMost                 = $false

$gbxSettings                     = New-Object system.Windows.Forms.Groupbox
$gbxSettings.height              = 76
$gbxSettings.width               = 878
$gbxSettings.BackColor           = "#ffffff"
$gbxSettings.text                = "Settings"
$gbxSettings.location            = New-Object System.Drawing.Point(15,11)

$lblServer                       = New-Object system.Windows.Forms.Label
$lblServer.text                  = "Server:"
$lblServer.AutoSize              = $true
$lblServer.width                 = 25
$lblServer.height                = 10
$lblServer.location              = New-Object System.Drawing.Point(21,31)
$lblServer.Font                  = 'Microsoft Sans Serif,10'
$lblServer.ForeColor             = "#000000"

$txtServer                       = New-Object system.Windows.Forms.TextBox
$txtServer.multiline             = $false
$txtServer.text                  = "localhost"
$txtServer.width                 = 118
$txtServer.height                = 20
$txtServer.location              = New-Object System.Drawing.Point(85,28)
$txtServer.Font                  = 'Microsoft Sans Serif,10'

$lblDatbase                      = New-Object system.Windows.Forms.Label
$lblDatbase.text                 = "Database:"
$lblDatbase.AutoSize             = $true
$lblDatbase.width                = 25
$lblDatbase.height               = 10
$lblDatbase.location             = New-Object System.Drawing.Point(243,31)
$lblDatbase.Font                 = 'Microsoft Sans Serif,10'

$txtDatabase                     = New-Object system.Windows.Forms.TextBox
$txtDatabase.multiline           = $false
$txtDatabase.text                = "AdventureWorksDW2016"
$txtDatabase.width               = 193
$txtDatabase.height              = 20
$txtDatabase.location            = New-Object System.Drawing.Point(312,27)
$txtDatabase.Font                = 'Microsoft Sans Serif,10'

$chkIsSelect                     = New-Object system.Windows.Forms.CheckBox
$chkIsSelect.text                = "Is Select?"
$chkIsSelect.AutoSize            = $false
$chkIsSelect.width               = 95
$chkIsSelect.height              = 20
$chkIsSelect.location            = New-Object System.Drawing.Point(543,28)
$chkIsSelect.Font                = 'Microsoft Sans Serif,10'

$cmbRowLimit                     = New-Object system.Windows.Forms.ComboBox
$cmbRowLimit.text                = "10"
$cmbRowLimit.width               = 100
$cmbRowLimit.height              = 20
@('10','100','1000','ALL') | ForEach-Object {[void] $cmbRowLimit.Items.Add($_)}
$cmbRowLimit.location            = New-Object System.Drawing.Point(697,28)
$cmbRowLimit.Font                = 'Microsoft Sans Serif,10'

$lblLimit                        = New-Object system.Windows.Forms.Label
$lblLimit.text                   = "Limit:"
$lblLimit.AutoSize               = $true
$lblLimit.width                  = 25
$lblLimit.height                 = 10
$lblLimit.location               = New-Object System.Drawing.Point(650,28)
$lblLimit.Font                   = 'Microsoft Sans Serif,10'

$txtQuery                        = New-Object system.Windows.Forms.TextBox
$txtQuery.multiline              = $true
$txtQuery.text                   = "SELECT * FROM "
$txtQuery.width                  = 882
$txtQuery.height                 = 189
$txtQuery.location               = New-Object System.Drawing.Point(13,198)
$txtQuery.Font                   = 'Microsoft Sans Serif,10'

$btnExecute                      = New-Object system.Windows.Forms.Button
$btnExecute.BackColor            = "#9b9b9b"
$btnExecute.text                 = "Execute"
$btnExecute.width                = 90
$btnExecute.height               = 30
$btnExecute.location             = New-Object System.Drawing.Point(354,431)
$btnExecute.Font                 = 'Microsoft Sans Serif,10'

$btnClose                        = New-Object system.Windows.Forms.Button
$btnClose.BackColor              = "#9b9b9b"
$btnClose.text                   = "Close"
$btnClose.width                  = 78
$btnClose.height                 = 30
$btnClose.location               = New-Object System.Drawing.Point(470,432)
$btnClose.Font                   = 'Microsoft Sans Serif,10'

$frmMain.controls.AddRange(@($gbxSettings,$txtQuery,$btnExecute,$btnClose))
$gbxSettings.controls.AddRange(@($lblServer,$txtServer,$lblDatbase,$txtDatabase,$chkIsSelect,$cmbRowLimit,$lblLimit))

$btnExecute.Add_Click({ btnExecute_Click })
$btnClose.Add_Click({ btnClose_Click })

