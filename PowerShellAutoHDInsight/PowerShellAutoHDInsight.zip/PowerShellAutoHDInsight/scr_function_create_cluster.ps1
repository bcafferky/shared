﻿
function New-udfHDICluster 
{ 
<#
        .DESCRIPTION
        Creates an HDInsight cluster.

        .PARAMETER hdiclustername
        Cluster name that is also used as part of other object names such as rgclustername for resource group.

        .PARAMETER password
        Password for cluster.  Must be secure with upper case, > 6 characters, and at least one special character.

        .EXAMPLE
        New-udfHDICluster -hdiclustername "Demo1" -password "Mypassword12*" -location "EastUS" `

        .NOTES
        Supports PowerShell common parameters such as Verbose. 
#>

 [CmdletBinding()]
        param (
              [string]$hdiclustername,
              $spassword,
              [string]$location = "EastUS",
              [string]$httpUserName = "hduser",
              [string]$sshUserName = "sshuser"
          )

   $resourceGroupName = "rg_" + $hdiclustername
   $storageAccountName = "sa" + $hdiclustername
   $containerName = "hdp" + $hdiclustername
   $clusterName = $hdiclustername
   $clusterNodes = 1

   # $spassword = ConvertTo-secureString $password -AsPlainText -Force

   Write-Verbose "Creating HDInsight Cluster with the following settings..."
   Write-Verbose "========================================================="
   Write-Verbose " "
   Write-Verbose "Resource Group: $resourceGroupName" 
   Write-Verbose "Storage Account Name: $storageAccountName"
   Write-Verbose "Container Name: $containerName"
   Write-Verbose "Cluster Name: $clusterName"
   Write-Verbose "Number of Nodes: $clusterNodes"
   Write-Verbose "User Name: $httpUserName"
   Write-Verbose "SSH User Name: $sshUserName"

#   Login-AzureRmAccount

   #Create a resource group
   New-AzureRmResourceGroup -Name $resourceGroupName -Location $location
   
   #Create a storage account
   Write-Output "Creating storage account..."
   New-AzureRmStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName -Type "Standard_GRS" -Location $location
   
   #Create a Blob storage container
   Write-Output "Creating container..."
   $storageAccountKey = Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName | %{ $_[0].Value }
   $destContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey[0]
   New-AzureStorageContainer -Name $containerName -Context $destContext
   
   #Create a cluster
   Write-Output "Creating HDInsight cluster..."
   $httpCredential = New-Object System.Management.Automation.PSCredential ($httpUserName, $spassword)
   $sshCredential = New-Object System.Management.Automation.PSCredential ($sshUserName, $spassword)
   New-AzureRmHDInsightCluster -ResourceGroupName $resourceGroupName -ClusterName $clusterName -ClusterType Hadoop -Location $location -DefaultStorageAccountName "$storageAccountName.blob.core.windows.net" -DefaultStorageAccountKey $storageAccountKey[0] -DefaultStorageContainer $containerName -ClusterSizeInNodes $clusterNodes -OSType Linux -HttpCredential $httpCredential -SshCredential $sshCredential
   Write-Output "Finished...!"

}

<# 
 
 $p_hdiclustername = 'hdibcafferk123a'
 $p_location = 'EastUS'
 $p_httpUserName = 'bcafferky'
 $p_sshUserName = 'sshbcafferky'
 
 $p_password = Read-Host "Password" -asSecureString


 New-udfHDICluster -hdiclustername $p_hdiclustername -spassword $p_password -location $p_location -httpUserName $p_httpUserName -sshUserName $p_sshUserName -Verbose 

#>

