﻿param (
              [string]$hdiresourcegroup
          )

# *** This will delete everything and cannot be undone!! ***

$hdiresourcegroup = "rg_hdibcafferk123a"
Remove-AzureRmResourceGroup -Name $hdiresourcegroup -Force