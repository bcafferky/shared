﻿param (
              [string]$hdiclustername
       )

Import-Module AzureRM

#  $hdiclustername = 'hdibcafferk123a'

Remove-AzureRmHDInsightCluster -ClusterName $hdiclustername