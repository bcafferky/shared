'''
Python program demonstrating string variables
'''

name = 'Luke_SkywaLker'

print("01234567890123")
print(name)

'''
print('name[0]: ', name[0])      # print first character
print('name[6:8]: ', name[6:8])  # chars 7 thru 8 (not 9)
print('name[-1]:  ', name[-1])    # last character

print("name.count('k'): ", name.count('k')) # get count of string in string
print('len(name): ', len(name)) # get the length of the string
print('"Sky" in name: ', "Sky" in name) # is the string in the string?
print('"sky" in name: ', "sky" in name) #  case sensitity

'''
# formatting output...
title = 'Jedi Master' 

print('My name is {}'.format(name))
print('My name is {0} and I am a {1}'.format(name, title))
print('My name is {}'.format(name.title()))

correctname = name.replace("_", " ")
print('Fixed Name: ', correctname)




