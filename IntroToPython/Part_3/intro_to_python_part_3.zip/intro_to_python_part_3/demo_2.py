# Different Variable Types
# Author: Bryan Cafferky

first_name = 'Bryan'
last_name = 'Cafferky'
age = 30
weight = 145.5 # fractions not supported
is_minor = False

print('first_name', type(first_name))
print('last_name', type(last_name))
print('age', type(age))
print('weight', type(weight))
print('is_minor', type(is_minor))

