# Variable is use
# Author: Bryan Cafferky

print((55/100 * 20 + 3)
print("Hello Bryan. How are you?")
      

