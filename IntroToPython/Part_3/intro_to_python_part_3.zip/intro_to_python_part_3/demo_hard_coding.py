# Variable is use
# Author: Bryan Cafferky

print("Circle's area is ", 3.14 * (15**2) )
print((55/100 * 20 + 3))
print("Hello Bryan. How are you?")
      

