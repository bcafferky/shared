# Variable is use
# Author: Bryan Cafferky
# Purpose:  Evaluate if the area will fit my couch.

name = input("What is your name? ")
width = int(input("Enter the width in feet: "))
length = int(input("Enter the length in feet: "))

area = width * length
area_needed = 100

will_fit_couch = (area > area_needed)

print('Area is', area)
print('Is the area large enough?', will_fit_couch)


