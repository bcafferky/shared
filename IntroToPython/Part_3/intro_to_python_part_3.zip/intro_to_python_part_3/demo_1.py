# Calculating the area
# Author: Bryan Cafferky

width = 10
height = 5
area = height * width

print("Area is ", area)

print(type(width))
