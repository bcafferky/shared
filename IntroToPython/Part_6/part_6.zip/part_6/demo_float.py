'''
Program:  demo_float.py

Author: Bryan Cafferky 
'''

price = 12.95
discount_rate = .0575
discount_amount = price * discount_rate
tax_rate = .07
tax_amount = price * tax_rate
huge_amount = 152323230 * 15002432350000.22323323

# print the numbers
print('Original price: ', price)
print('data type of price: ', type(price))
print('Discount rate: ' ,discount_rate)
print('Discount amount: ', discount_amount)
print('Price after discount: ', price - discount_amount)
print('Tax rate: ', tax_rate)
print('Tax amount: ', tax_amount)
print('Price after discount and taxes: ', price - discount_amount + tax_amount)
print('Huge amount: ', huge_amount)  # scientific notation

