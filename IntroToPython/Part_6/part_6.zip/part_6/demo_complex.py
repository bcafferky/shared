'''
Program:  demo_complex.py

Author: Bryan Cafferky 
'''

x = 3+5j
y = 5j
z = -5j


# print the numbers
print('x= ', x)
print('z=:' , y)
print('z= ', z)
print('data type of z:  ', type(z))
