x = 5
y = 7
print(x + y)
