import pyttsx3

xengine = pyttsx3.init()
engine.say("I will speak this text")
engine.runAndWait()
