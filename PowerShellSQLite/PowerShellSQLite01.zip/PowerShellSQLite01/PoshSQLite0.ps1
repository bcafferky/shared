﻿<#
   From the GitHub repository of Bryan Cafferky
   - Code to demonstrate only.  Not tested for production.
     Use at your own risk.
#>

#  Only install the PSSQLite module if your company and you
#  Get proper security approvals at your organization!!!  
#  Test the code first!!! 
#  You Will need to override the warning.

<#
Most of this code was copied from RamblingCookieMonster

https://github.com/RamblingCookieMonster/PSSQLite

#>

# One time setup:
    # Download the repository
    # Unblock the zip
    # Extract the PSSQLite folder to a module path (e.g. $env:USERPROFILE\Documents\WindowsPowerShell\Modules\)

    # Simple alternative, if you have PowerShell 5, or the PowerShellGet module:
    #    Install-Module PSSQLite

    # Import the module.
    # Import-Module PSSQLite    #Alternatively, Import-Module \\Path\To\PSSQLite

<#
     Code is designed to be run a few lines at a time to demonstrate 
     how things work.

     Run the code as indicated.  You can select the code and click on the Run Selection toolbar button.

#>

#
# You must have the PSSQLite module installed to run the code below.
#

<# 
   Run Code Block 1 starting here...
#>
Clear-Host

# Install-Module PSSQLite -Verbose # Requires you to run this as administrator
Import-Module PSSQLite -Verbose

# Get commands in the module
Get-Command -Module PSSQLite

<# 
           End of Code Block
#>


<# 
   Run Code Block 2 starting here...
#>
# Get help for a command
Get-Help Invoke-SQLiteQuery -Full

<# 
           End of Code Block
#>


<#  Let's try it out! #>

<# 
   Run Code Block 3 starting here...
#>

# Create the database
     $database = "mydb.db"
     $conn = New-SQLiteConnection -DataSource $database
     $conn

<# 
           End of Code Block
#>


<# 
   Run Code Block 4 starting here...
#>

# Create a database and a table
    $Query = "CREATE TABLE NAMES (fullname VARCHAR(20) PRIMARY KEY, 
              surname TEXT, 
              givenname TEXT, 
              BirthDate DATETIME)"


#    $Database = ":MEMORY:" to create an in-memory database.

    Invoke-SqliteQuery -Query "DROP TABLE IF EXISTS NAMES" -SQLiteConnection $Conn 

#   Format   Invoke-SqliteQuery -Query $Query -DataSource $DataSource - assumes database exists.

    Invoke-SqliteQuery -Query $Query -SQLiteConnection $Conn 
<# 
           End of Code Block
#>


<# 
   Run Code Block 5 starting here...
#>

# View table info
    Invoke-SqliteQuery -SQLiteConnection $Conn  -Query "PRAGMA table_info(NAMES)" | Out-GridView
<# 
           End of Code Block
#>

<# 
   Run Code Block 6 starting here...
#>

# Insert some data, use parameters for the fullname and birthdate
    $query = "INSERT INTO NAMES (fullname, surname, givenname, birthdate) VALUES (@full, 'Cookie', 'Monster', @BD)"

    Invoke-SqliteQuery -SQLiteConnection $Conn  -Query $query -SqlParameters @{
        full = "Cookie Monster"
        BD   = (get-date).addyears(-3)
    }

<# 
           End of Code Block
#>

<# 
   Run Code Block 7 starting here...
#>

# View the data
    Invoke-SqliteQuery -SQLiteConnection $Conn -Query "SELECT * FROM NAMES"
<# 
           End of Code Block
#>

<# 
   Run Code Block 8 starting here...
#>

#Build up some fake data to bulk insert, convert it to a datatable
    $DataTable = 1..10000 | %{
        [pscustomobject]@{
            fullname = "Name $_"
            surname = "Name"
            givenname = "$_"
            BirthDate = (Get-Date).Adddays(-$_)
        }
    } | Out-DataTable

<# 
           End of Code Block
#>


<# 
   Run Code Block 9 starting here...
#>

#Insert the data within a single transaction (SQLite is faster this way)
    Invoke-SQLiteBulkCopy -DataTable $DataTable -SQLiteConnection $Conn -Table Names -NotifyAfter 1000 -verbose

<# 
           End of Code Block
#>


<# 
   Run Code Block 10 starting here...
#>

#   View all the data!
    Invoke-SqliteQuery -SQLiteConnection $Conn -Query "SELECT * FROM NAMES LIMIT 5"
<# 
           End of Code Block
#>
