﻿Clear-Host

Import-Module udm_application -Verbose -Force

Invoke-UdfAddNumber 1 2

Get-Command -Module udm_application 

