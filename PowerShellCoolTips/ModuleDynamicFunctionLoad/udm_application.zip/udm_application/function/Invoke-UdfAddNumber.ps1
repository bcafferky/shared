﻿function Invoke-UdfAddNumber([int]$p_int1, [int]$p_int2)
{
<#
     .SYNOPSIS 
     Adds two numbers together as opposed to apart.

     .DESCRIPTION
     This cool function adds two numbers together.

     .PARAMETER $p_int1
     The first number of your choosing.

      .PARAMETER $p_int2
     The second number of your choosing.
      
     .INPUTS
     This function does not support piping.

     .OUTPUTS
     Returns the sum.

     .EXAMPLE
     Invoke-UdfAddNumber 5 10

#>
	
	 Write-Verbose 'You will never see this.'
	
     Return ($p_int1 + $p_int2)
}
