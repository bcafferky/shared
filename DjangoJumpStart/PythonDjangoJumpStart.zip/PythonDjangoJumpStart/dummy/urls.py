from django.urls import path
from . import views

urlpatterns = [
    path('',views.DummyListView.as_view(), name='dummy_list'),
    path('<int:pk>/',views.DummyDetailView.as_view(), name='dummy_detail'),
    path('new/',views.DummyCreateView.as_view(), name='dummy_new'),
    path('<int:pk>/edit',views.DummyUpdateView.as_view(), name='dummy_edit'),
    path('<int:pk>/delete',views.DummyDeleteView.as_view(), name='dummy_delete'),
]