from django.shortcuts import render

# Create your views here.
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from . models import Dummy


class DummyListView(ListView):
    model =  Dummy
    template_name = 'dummy_list.html' 

class DummyDetailView(DetailView):
    model =  Dummy
    template_name = 'dummy_detail.html'   

class DummyCreateView(CreateView):
    model =  Dummy
    template_name = 'dummy_new.html' 
    fields = '__all__'

class DummyUpdateView(UpdateView):
    model =  Dummy
    template_name = 'dummy_edit.html' 
    fields = '__all__'

class DummyDeleteView(DeleteView):
    model =  Dummy
    template_name = 'dummy_delete.html' 
    success_url = reverse_lazy('dummy_list')     
 