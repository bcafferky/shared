-- Create Login in Master  - Note: Check Policy option!!!

CREATE LOGIN bryantuser WITH password='bryantuser123' , CHECK_POLICY = OFF;

-- The following lines must be done in the specific database!!!

CREATE USER bryantuser FROM LOGIN bryantuser;

EXEC sp_addrolemember 'db_owner', 'bryantuser';