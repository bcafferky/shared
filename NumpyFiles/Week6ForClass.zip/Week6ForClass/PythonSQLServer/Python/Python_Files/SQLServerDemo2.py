# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 10:35:06 2019

@author: brcaffer

links:
    
    https://blogs.msdn.microsoft.com/cdndevs/2015/03/11/python-and-data-sql-server-as-a-data-source-for-python-applications/
    
    https://tomaztsql.wordpress.com/2018/07/15/using-python-pandas-dataframe-to-read-and-insert-data-to-microsoft-sql-server/
    
"""

## From SQL to DataFrame Pandas
import pandas as pd
import pyodbc

sql_conn = pyodbc.connect("DRIVER={ODBC Driver 13 for SQL Server};"
                          "SERVER=localhost;"
                          "DATABASE=AdventureWorksDW2017;"
                          "Trusted_Connection=yes;") 


query = '''SELECT * FROM dbo.DiMDate'''
                 
df = pd.read_sql(query, sql_conn)

print(df.head(3))

print(type(df))


# using credentials...

sql_conn2 = pyodbc.connect("DRIVER={ODBC Driver 13 for SQL Server};"
                          "SERVER=localhost;"
                          "DATABASE=AdventureWorksDW2017;"
                          "Trusted_Connection=yes;"
                          "uid=bryantuser;pwd=Bryantuser123?") 


query = '''SELECT top 5 * FROM dbo.DiMDate'''
                 
df = pd.read_sql(query, sql_conn)

print(df.head(3))

print(type(df))