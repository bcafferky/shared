SELECT SUM(SalesAmount) as SalesAmount, 
EnglishProductCategoryName as ProductCategory
from dbo.FactInternetSales s
INNER JOIN dbo.DimProduct p
on (s.ProductKey = p.ProductKey)
INNER JOIN dbo.DimProductSubCategory ps
on (p.ProductSubcategoryKey = ps.ProductSubcategoryKey)
INNER JOIN dbo.DimProductCategory pc
on (ps.ProductCategoryKey = pc.ProductCategoryKey)
GROUP BY EnglishProductCategoryName
