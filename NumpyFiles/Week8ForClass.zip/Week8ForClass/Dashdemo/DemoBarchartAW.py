import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd

df = pd.read_excel(
    "https://github.com/chris1610/pbpython/blob/master/data/salesfunnel.xlsx?raw=True"
)

import pyodbc
import plotly.graph_objs as go

# Custom modules...
import datautil as du

sqlquery1 = '''
SELECT [FiscalYear],
       [SalesTerritoryCountry] as Country,
	   [EnglishProductCategoryName] as Category,
       sum([SalesAmount]) as SalesAmount
FROM [dbo].[FactInternetSales] s
join [dbo].[DimDate]           d
on (s.OrderDateKey = d.DateKey)
join [dbo].[DimSalesTerritory] st
on (s.SalesTerritoryKey = st.SalesTerritoryKey) 
join [dbo].[DimProduct]          p
on (s.ProductKey = p.ProductKey)
join [dbo].[DimProductSubcategory] psc
on (p.ProductSubcategoryKey = psc.ProductSubcategoryKey)
join [dbo].[DimProductCategory] pc
on (psc.ProductCategoryKey = pc.ProductCategoryKey) 
GROUP BY [FiscalYear], [SalesTerritoryCountry], [EnglishProductCategoryName] 
'''

df = du.get_db_data(sqlquery1) 

pv = pd.pivot_table(df, index=['FiscalYear'], columns=["Category"], values=['SalesAmount'], aggfunc=sum, fill_value=0)


trace1 = go.Bar(x=pv.index, y=pv[('SalesAmount', 'Bikes')], name='Bikes')
#trace2 = go.Bar(x=pv.index, y=pv[('SalesAmount', 'Components')], name='Components')
trace3 = go.Bar(x=pv.index, y=pv[('SalesAmount', 'Clothing')], name='Clothing')
trace4 = go.Bar(x=pv.index, y=pv[('SalesAmount', 'Accessories')], name='Accessories')

app = dash.Dash()
app.layout = html.Div(children=[
    html.H1(children='Sales Report'),
    html.Div(children='''National Sales Report.'''),
    dcc.Graph(
        id='example-graph',
        figure={
            'data': [trace1, trace3, trace4],
            'layout':
            go.Layout(title='Sales by Year, Country', barmode='stack')
        })
])

if __name__ == '__main__':
    app.run_server(debug=True)