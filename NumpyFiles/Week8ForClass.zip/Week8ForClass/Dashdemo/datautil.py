
import pyodbc
import pandas as pd

def get_db_data(sqlstatement, 
                driver = "{ODBC Driver 13 for SQL Server}",
                server = "localhost",
                database = "AdventureWorksDW2017"):
    
    '''
        get_db_data takes a SQL query as input and returns a result
    
        arguments:
        
            sqlstatement = query you want to execute
            driver = database driver to use
            server = database server name
            database = database name 
    '''

    conn = pyodbc.connect("Driver=" + driver + ";"
                          "Server=" + server + ";"
                          "Database=" + database + ";"
                          "Trusted_Connection=yes;")

    
    result = pd.read_sql(sqlstatement, conn)
    
    # cur.close()
    conn.close()
    
    return result

print('Loaded')    