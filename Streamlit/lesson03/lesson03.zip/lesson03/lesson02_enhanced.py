import streamlit as st
import random

# numguess with the following enhancements:
#
# - the random number is stored in the session state.
# - sidebar added
# - coloring text
# - showing an image

if 'number' in st.session_state:
   num = st.session_state['number']
else:
    num = random.randrange(1, 10)
    st.session_state['number'] = num   

col1, col2 = st.columns(2)

with col1:
    st.title('Welcome to Number Guess')

with col2:
    st.image('guess.jpg')    

st.write('### :blue[where you guess a number]')

txt_guess = int(st.text_input('Enter a number between 1 and 10: ', 1))

btn_start = st.button('Start Again')

if btn_start:
    num = random.randrange(1, 10)
    st.write(num)
    st.session_state['number'] = num

btn_guess = st.button('Make Guess')

if btn_guess:
    if txt_guess == num:
        st.write('You Win')
        st.balloons()
    else:
        st.write('Sorry. Wrong number. Try again.')

btn_show = st.button('Show Number')

if btn_show:
    st.write('The number is ', num)

with st.expander("Help..."):
    st.write('''
    Press Start and a random number between 1 and 10 will be generated.
    Try to guess the number by entering your guess in the text box and
    clicking "Make Guess"
    ''')

with st.sidebar:
    st.markdown('#### Copyright Acme Games 2023')
    st.success('Licencse Validated')
    st.slider('Rate this game: ', 0, 10) 