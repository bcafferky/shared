﻿function Invoke-udfAdd2Numbers 
{ 
<#

        .SYNOPSIS
        In the beginning, there were two numbers...

        .DESCRIPTION
        Adds two numbers together.

        .PARAMETER Number1
        Number1.  First number.

        .PARAMETER Number2
        Number2.  Second Number.

        .EXAMPLE
        Invoke-udf2AddNumbers -Number1 5 -Number2 10

        .NOTES
        Demo of a simple function. 
#>

  [CmdletBinding()]  # This enables common parameters!!!
        param (
              [int]$Number1,
              [int]$Number2
          )

   #  If the -Verbose common parameter is passed, these messages will display.
   Write-Verbose "The numbers you passed were:"
   Write-Verbose "==========================="
   Write-Verbose "`t Number1: $Number1"  # special char prefix is `
   Write-Verbose "`n`t Number2: $Number2" # n=newline, t=tab

   # Output messages are sent back to the caller!!!
   # Do not use Write-Host
   Write-Output 'Always print Thank You!'  # This will cause problems.

   # https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/write-information?view=powershell-6
   Write-Information 'Info Thank You!' -InformationAction Continue

   # Add the numbers...
   $NumberSum = $Number1 + $Number2

   Return $NumberSum
 
}

<# 

       Clear-Host

       Invoke-udfAdd2Numbers -Number1 5 -Number2 10 

       Invoke-udfAdd2Numbers -Number1 5 -Number2 10 -Verbose

       Help Invoke-udfAdd2Numbers

       Show-Command Invoke-udfAdd2Numbers
 
#>

