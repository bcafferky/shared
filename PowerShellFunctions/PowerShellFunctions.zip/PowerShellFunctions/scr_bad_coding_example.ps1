﻿function Display-Message ($yourmessage)
{
     Write-Verbose 'Will never display'

     Write-Host "Your message is:  $yourmessage"
}

<#

Display-Message "Hi Bryan"

#>

