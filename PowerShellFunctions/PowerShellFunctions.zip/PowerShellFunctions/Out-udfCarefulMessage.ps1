﻿<#
       Stop-Process -Name notepad -WhatIf
       Stop-Process -Name notepad -Confirm
#>

function Out-udfCarefulMessage  
{ 
<#
        .DESCRIPTION
        Output message and may delete a file so uses SupportsShouldProcess.
#>

  [CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='High')] 
  param()

  Write-Output "Writing a message is not risky."

  Write-Output "`nBut the following code is..."

  "xx" > TestFile.txt

  # Risky code follows...
  IF ($PSCmdlet.ShouldProcess("Remove TestFile.txt"))
  {
    Remove-Item('TestFile.txt') 
  }
 
}

<# 

       Clear-Host

       "xx" > TestFile.txt

       Cmdlet example...

       Stop-Process -Name notepad -WhatIf
       Stop-Process -Name notepad -Confirm


       Custom function example...

       Out-udfCarefulMessage
       Out-udfCarefulMessage -WhatIf
       Out-udfCarefulMessage -Confirm

#>

