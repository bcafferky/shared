﻿# Call a module's functions...

Import-Module udm_application -Force 

Get-Command -Module udm_application

Get-Help udm_application

Get-Help Invoke-UdfAddNumber

Invoke-UdfAddNumber 5 6

Show-Command

