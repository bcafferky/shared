﻿<#

    Disclaimer:  

    This code is only for demonstration and should not be used in production.

#>

<#  Things to note:
       - Function/cmdlet naming conventions.
       - Comment tags.
       - CmdletBinding attribute.
       - Function definition and use.
       - Parameter default values.
#>

$ServerName = "prodserver1"

function Write-udfMessageBox {
<#
  Function to display a message box inspired by the blog below.
  http://powershell-tips.blogspot.com/2012/02/display-messagebox-with-powershell.html
#>

  <#
     .SYNOPSIS 
     Displays a message box with selected buttons.

     .DESCRIPTION
     Just a handy function to display a Windows message box.

     .PARAMETER $title
     Text displyed in the title bar.

      .PARAMETER $message
     Text message to display.

      .PARAMETER $buttons
     Optional buttons to display. Validation set will show the list of valid values.

     .INPUTS
     This function does not support piping.

     .OUTPUTS
     Returns the name of the button selected.

     .EXAMPLE
     Write-udfMessageBox -title "Hey!"  -message "What do you want?" -buttons 'Abort Retry Ignore'

#>
#>
 [CmdletBinding()]
 param (
         [string]$title = "Message",
         [Parameter(Mandatory=$true)]
         [string]$message,
         [Parameter(Mandatory=$true)]
         [ValidateSet("Ok","Ok Cancel","Abort Retry Ignore", "Yes No Cancel", "Yes No", "Retry Cancel")] 
         [string]$buttons
       )

    #  Good chance to use a hash table to translate the code for us...
    $buttonhash = @{ "Ok"        = 0; 
                     "OK Cancel" = 1; 
                     "Abort Retry Ignore" = 2; 
                     "Yes No Cancel" = 3; 
                     "Yes No" = 4;
                     "Retry Cancel" = 5 
                   }
    
   
    RETURN [System.Windows.Forms.MessageBox]::Show("$message" , "$title" , $buttonhash[$buttons])

}

function Out-UdfSpeech  
{ 
 <#
     .SYNOPSIS 
     Speaks the string passed to it.

     .DESCRIPTION
     This function uses the SAPI interface to speak.

     .PARAMETER $speakit
     The string to be spoken.

     .INPUTS
     This function does not support piping.

     .OUTPUTS
     Describe what this function returns.

     .EXAMPLE
     Out-UdfSpeach 'Something to be said.'

     .LINK
     www.SAPIHelp.com.

#>
[CmdletBinding()]
        param (
              [string]$speakit = 'What do you want me to say?',
              [int]$volume = 100
          )
  #  Fun using SAPI - the text to speech thing....    

  $speaker = new-object -com SAPI.SpVoice 
  $speaker.Volume = $volume

  $speaker.Speak($speakit, 1) | out-null

}

<#  Example call...

Get-Help Out-UdfSpeech
Out-UdfSpeech 
Out-UdfSpeech 'It is a beautiful day!' 100

#>  

<# Things to note...
   - Leveraging Windows to support user interaction.
   - Using cmdlets in assigning parameter default values.
   - Using environment variables.
   - CmdletBinding and Write-Verbose.
#>
Function Get-UdfFileName
{  
[CmdletBinding()]
        param (
              [string]$InitialDirectory = (Join-Path -Path $env:HOMEDRIVE -ChildPath $env:HOMEPATH) 
          )

 [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

 $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
 $OpenFileDialog.initialDirectory = $initialDirectory
 $OpenFileDialog.filter = "All files (*.*)| *.*"
 $OpenFileDialog.ShowDialog() | Out-Null
 $OpenFileDialog.filename

 Write-Verbose "You selected $OpenFileDialog ."
}

<# Example Call...
  Get-UdfFileName -Verbose
#>


<# Things to note...
   - Combining functions.
   - Using PS variables.
   - Nesting cmdlets withing parentheses.
   - Using a module.
   - $PSScriptRoot
   - Creating a script module.
#>
Function Out-UdfSpeakFileContents
{  
[CmdletBinding()]
        param (
              [string]$InitialDirectory = ($PSScriptRoot) 
          )

       [string]$speech = Get-Content (Get-UdfFileName -InitialDirectory $InitialDirectory)
       Out-UdfSpeech $speech

}

<# Example Call...
  Out-UdfSpeakFileContents
#>

function Invoke-UdfSQLStatement
{ 
 [CmdletBinding()]
        param (
              [string]$Server,
              [string]$Database,
              [string]$SQL,
              [switch]$IsSelect
          )

  Write-Verbose "open connecton"

  $conn = new-object System.Data.SqlClient.SqlConnection("Data Source=$Server;Integrated Security=SSPI;Initial Catalog=$Database");

  $conn.Open()

  $command = new-object system.data.sqlclient.Sqlcommand($SQL,$conn)

  if ($IsSelect) 
  { 
     
     $adapter = New-Object System.Data.sqlclient.SqlDataAdapter $command
     $dataset = New-Object System.Data.DataSet
     $adapter.Fill($dataset) | Out-Null
     $conn.Close()
     RETURN $dataset.tables[0] 
  }
  Else
  {
     $command.ExecuteNonQuery()
     $conn.Close()
  }
}

<# Example call 
Invoke-UdfSQLStatement -Server '(local)' -Database 'Development' -SQL 'select top 10 * from dbo.orders' -IsSelect 
#>

<# Demo of using modules to support configuraton...

Import-Module umd_appconfig

Get-UdfConfiguation 'EDWServer'

Invoke-UdfSQLStatement -Server (Get-UdfConfiguation 'EDWServer') `
                       -Database 'Development' -SQL 'select top 10 * from dbo.orders' -IsSelect 


#>

function Show-Process($Process, [Switch]$Maximize)
{
#  From http://community.idera.com/powershell/powertips/b/tips/posts/bringing-window-in-the-foreground
  $sig = '
    [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);
  '
  
  if ($Maximize) { $Mode = 3 } else { $Mode = 4 }
  $type = Add-Type -MemberDefinition $sig -Name WindowAPI -PassThru
  $hwnd = $process.MainWindowHandle
  $null = $type::ShowWindowAsync($hwnd, $Mode)
  $null = $type::SetForegroundWindow($hwnd) 
}

Export-ModuleMember -Function * -Variable * 


