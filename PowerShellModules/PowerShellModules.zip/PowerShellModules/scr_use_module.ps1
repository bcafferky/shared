﻿<#

   For more information see..
      https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/import-module?view=powershell-5.1

#>

<#  Note about Module Manifest...

    RootModule = 'udm_utility.psm1'

    Show-Command New-ModuleManifest
#>

#  Clear out a module from memory...
Remove-Module udm_utility

# The basic way to load a module...

$env:PSModulePath

Import-Module udm_utility -Force -Verbose

Write-udfMessageBox -title "Good day!" -message "What do you want to do?" -buttons 'Yes No Cancel'

Get-Command -Module udm_utility

Get-Help udm_utility

Get-Help Write-udfMessageBox

# Testing modules...
Import-Module -Name c:\ps-test\modules\test -Verbose

# Using a prefix to avoid naming conflicts.

Import-Module udm_utility -Prefix bpc

Write-bpcudfMessageBox 

# Using a module as an object...

$utility = Import-Module udm_utility -AsCustomObject

$utility.ServerName

#  I knew the dash would cause issues somewhere...
$utility.'Get-UdfFileName'()

New-ModuleManifest -Path 'c:\Bryan\documents\windowspowershell\modules\udm_utility\udm_utility.psd1