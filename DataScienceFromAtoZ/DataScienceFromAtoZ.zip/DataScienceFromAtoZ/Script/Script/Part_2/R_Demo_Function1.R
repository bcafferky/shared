Square <- function(x) {
  return(x^2)
}

print(Square(4))
print(Square(x=4)) # same thing

Square(c(4,2))

myvect = 1:5

Square(myvect)


