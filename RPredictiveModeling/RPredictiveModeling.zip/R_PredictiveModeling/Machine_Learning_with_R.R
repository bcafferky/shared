
# Using the Built-In Iris data set.

# What does the structure of the data look like?
  str(iris, vec.len=1)

# See some sample data...
  head(iris)
  tail(iris)

# What are the basic statistics...
  summary(iris)

# Visualize some data...
  plot(iris$Petal.Width,pch=16,col='blue',main='Iris Petal Width')
  
  library(ggplot2)
  qplot(Petal.Width, Sepal.Width, data=iris, colour=Species, size=I(4))

  hist(iris$Petal.Width,x.lab="petal width", col="lightblue", main='Iris Petal Width')

  boxplot(iris,col=c("blue","red","sienna","palevioletred1","blue"),ylab="Centimeters")

# How do the columns relate to each other?
  myiris <- 
    data.frame(iris$Sepal.Length,iris$Sepal.Width,iris$Petal.Length,iris$Petal.Width)
  
  d <- data.frame(myiris)
  dcor <- as.matrix(cor(d))
  dcor

  library(psych)
  pairs.panels(iris)

#  Let's create a model to predict the species 
#  based on the other columns.

# Train the Model: Separate Training/Test Data

# We need two sets of data...
#   1 - one set to be used to train the model.
#   2 - another set to be used to score the model.

#  Separate my training and scoring data sets...
set.seed(1234)
ind <- sample(2, nrow(iris), replace=TRUE, prob=c(0.67, 0.33))

iris.training <- iris[ind==1, 1:4]   # training data
iris.test <- iris[ind==2, 1:4]       # data to test the model

#  What we want to predict...
iris.trainLabels <- iris[ind==1, 5]  # actual species for training data
iris.testLabels <- iris[ind==2, 5]   # actual species for test data

# Let's use the Decision Tree model.
# From  http://davetang.org/muse/2013/03/12/building-a-classification-tree-in-r/
 library(tree)

 tree1 <- tree(Species ~ Sepal.Width + Sepal.Length + Petal.Length + Petal.Width,data = iris.training)

 plot(tree1)
 text(tree1)

# Let's use the Decision Tree Model we created...

 # Use the model to get classification...
 predict.list <- predict(tree1, iris.test, type="class")
 predict.list

# Score the model - how many errors did it make?
library(gmodels)
CrossTable(x = iris.testLabels, y =  predict.list, prop.chisq=FALSE)




