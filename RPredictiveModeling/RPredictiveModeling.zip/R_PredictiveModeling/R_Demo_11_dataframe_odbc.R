require(RODBC)

# Helped from: http://stackoverflow.com/questions/20310261/read-data-from-microsoft-sql-database-on-remote-desktop-via-r
# By: Sudip Kafle at http://stackoverflow.com/users/1159766/sudip-kafle

ufn_get_connection <- function(host, db, user=NULL, pass=NULL )
{
 
  if(is.null(pass)) 
  {     
    c <- odbcDriverConnect(connection=paste0("server=",host,
                                             ";database=",db,
                                             ";trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;"))
  }
  else
  {
    c <- odbcDriverConnect(connection=paste0("server=",host,
                                             ";database=",db,
                                             ";uid=",user,
                                             ";pwd=",pass,
                                             ";trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;"))
  }
  
    if(class(c) == 'RODBC') 
    {  
      writeLines("Successfilly opened connection to db")
      return(c)
    } 
    else
    {
      writeLines(paste0("Error opening connection: ", as.character(c)))
    }
  
}

# Connect using Windows Integrated Security...
myisconnection <- odbcDriverConnect(
  connection=paste0(
    "server=","(local)",
    ";database=","AdventureWorks2016",
    ";trusted_connection=true;Port=1433;driver={SQL Server};TDS_Version=7.0;"
  )
)

#  Get column list...
sqlColumns(myisconnection, "Sales.CreditCard")

# Do a query...
myresults <- sqlQuery(myisconnection, 
                      "select TOP 100 [CreditCardID]
                      ,[CardType]
                      ,[CardNumber]
                      ,[ExpMonth]
                      ,[ExpYear] from Sales.CreditCard", errors = TRUE)

# Display results...
myresults

class(myresults)

# Get statitics about the data frame...
summary(myresults)


