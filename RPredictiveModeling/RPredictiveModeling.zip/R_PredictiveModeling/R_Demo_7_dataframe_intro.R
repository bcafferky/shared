# data.frames....

setwd("D:\\DocumentsD\\Presentations\\R_Intro")

getwd()

salesdata <- read.csv("sales.csv",header=T,sep=",")

salesdata

class(salesdata)

#  Strings become factors...
salesdata[,2]

salesdata <- read.csv("sales.csv",header=T,sep=",", stringsAsFactors = FALSE)

salesdata[,2]  # Strings not factors anymore.

salesdata[salesdata$TotalSales > 120,2]


