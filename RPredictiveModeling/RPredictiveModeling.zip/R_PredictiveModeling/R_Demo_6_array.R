# Arrays...

myarray <- array(1:24, dim=c(3,4,2))

myarray

class(myarray)

#  dimension order  row, column, n

myarray[1,,]  # Row 1 in both sets...

myarray[,2,]  # Column 2 both sets...




