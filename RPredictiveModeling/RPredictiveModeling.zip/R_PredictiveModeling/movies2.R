library("ggplot2movies")

head(movies)

library(dplyr)

movies %>%
  group_by(Romance) %>%
  
  summarise(median(audience_score))

qplot(data = movies, x = best_actor_win, y = audience_score, geom = "boxplot")