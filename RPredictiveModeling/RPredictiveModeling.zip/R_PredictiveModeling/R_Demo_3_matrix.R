#  R is all about matrices (n dimensions)

#########
#    Matrix  - 2 dimensions 
#########
#  But wait!  We can do multimensional arrays (matrix) too...
mymat = matrix(c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15),nrow=3)
mymat

mymat[,1]

# Give names to columns...
colnames(mymat) <- c("First","Second","Third", "Fourth", "Five")
mymat

mymat[,'First']

# And actions still act on the array...
mymat / 2

#  Indexing can be done using conditional expressions.
mymat[1,3]
mymat[1,]
mymat[TRUE]
mymat[FALSE]
mymat > 5
mymat[mymat > 5]




