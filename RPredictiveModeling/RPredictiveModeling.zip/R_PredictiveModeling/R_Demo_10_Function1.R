Square <- function(x) {
  return(x^2)
}

print(Square(4))
print(Square(x<-4)) # same thing
