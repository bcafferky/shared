# For loop...

m=20;
for (k in 1:m)
{
  if (! k %% 2)  # Boolean result, 0 or 1...
    next
  print(k)
  print(k %% 2)
}

# While loop...
answer <- "N"
while (toupper(answer) != "Y")
{
  answer <- readline("Enter Y to exit: ")
  
  if (toupper(answer) != "Y")
  {
     print( "Ok.  Looping Again...")
  }
}

# repeat loop...
answer <- "N"
repeat
{
  answer <- readline("Enter Y to exit: ")
  
  if (toupper(answer) != "Y")
  {
    print( "Ok.  Looping Again...")
  }
  else 
     { 
       print("Ok. Quiting the loop.")
       break
     }
}
