
#  Data Tables...

#  *** data.table fun...
require(data.table)

mydt <- as.data.table(myresults)
str(mydt)  # get data table column info...

# no order to data...
mydt


# Show the object type of the recordset..
class(myresults)
class(mydt)

setkey(mydt, CardType)

#  Like setting a clustered index...
mydt

# List just card type...
myresults$CardType  # Not ordered...

mydt$CardType       # ordered...

head(mydt)

library(nycflights13)
require(data.table)

str(flights) 

dfflights = as.data.table(flights[1:30,])
x <- dfflights[month==1,.(avgtime = mean(na.omit(air_time))), by=carrier] 
x


