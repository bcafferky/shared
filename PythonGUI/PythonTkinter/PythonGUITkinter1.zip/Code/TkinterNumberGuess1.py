# Basic example of using Tkinter - Python 3 and above
# Useful links:
#    https://tkdocs.com/
#    https://docs.python.org/3/library/tk.html

from tkinter import *

# Create the Window and give it a title...
window = Tk()
window.title("Welcome to Number Guess")

# Set the Windows size...
window.geometry('900x150')

# Scale it up so we can see it better...
window.tk.call('tk', 'scaling', 3.0)

window.mainloop()
